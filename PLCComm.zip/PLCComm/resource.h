﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// PLCComm.rc에서 사용되고 있습니다.
//
#define IDD_PLCCOMM_DIALOG              102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_WRITE_DIALOG                131

#define IDC_LIST_BUFFERMEMORY           1000
#define IDC_EDIT_DEVICE                 1001
#define IDC_BTN_START                   1002
#define IDC_BTN_STOP                    1003
#define IDC_EDIT_UPDATECYCLE            1004
#define IDC_COMBO_DISPLAY               1005
#define IDC_BTN_OPEN                    1006
#define IDC_BTN_CLOSE                   1007
#define IDC_BTN_CHANGE                  1008
#define IDC_STATIC_STATE                1009

#define IDC_EDIT_BITDEVICE              1010
#define IDC_BTN_ON                      1011
#define IDC_BTN_OFF                     1012
#define IDC_BTN_TOGGLE                  1013
#define IDC_EDIT_WORDDEVICE             1014
#define IDC_EDIT_VALUE                  1015
#define IDC_RADIO_DEC                   1016
#define IDC_RADIO_STR                   1017
#define IDC_BTN_SET                     1018


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
